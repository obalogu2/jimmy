package com.theocc.mvg.foundation.math;

import java.util.function.DoubleFunction;

/**
 * An interface representing a univariate real function.
 * <p>
 * When a <em>user-defined</em> function encounters an error during
 * evaluation, the {@link #apply(double) apply} method should throw a
 * <em>user-defined</em> unchecked exception.</p>
 * <p>
 * The following code excerpt shows the recommended way to do that using
 * a root solver as an example, but the same construct is applicable to
 * ODE integrators or optimizers.</p>
 *
 * <pre>
 * private static class LocalException extends RuntimeException {
 *     // The x apply that caused the problem.
 *     private final double x;
 *
 *     public LocalException(double x) {
 *         this.x = x;
 *     }
 *
 *     public double getX() {
 *         return x;
 *     }
 * }
 *
 * private static class MyFunction implements UnivariateFunction {
 *     public double apply(double x) {
 *         double y = hugeFormula(x);
 *         if (somethingBadHappens) {
 *           throw new LocalException(x);
 *         }
 *         return y;
 *     }
 * }
 *
 * public void compute() {
 *     try {
 *         solver.solve(maxEval, new MyFunction(a, b, c), min, max);
 *     } catch (LocalException le) {
 *         // Retrieve the x apply.
 *     }
 * }
 * </pre>
 *
 * As shown, the exception is local to the user's code and it is guaranteed
 * that Apache Commons Math will not catch it.
 *
 * This interface is completely based on its Apache Common Math counterpart
 *
 */
@FunctionalInterface
public interface UnivariateFunction {
    /**
     * A Functional interface to Compute the apply of the function.
     *
     * @param x Point at which the function apply should be computed.
     * @return the apply of the function.
     * @throws IllegalArgumentException when the activated method itself can
     * ascertain that a precondition, specified in the API expressed at the
     * level of the activated method, has been violated.
     * When Commons Math throws an {@code IllegalArgumentException}, it is
     * usually the consequence of checking the actual parameters passed to
     * the method.
     */
    double apply(double x);

    default double andThen(UnivariateFunction univariateFunction, double x){
        return univariateFunction.apply(this.apply(x));
    }

    default <T> T andThen(DoubleFunction<T> function, double x)  {
        return function.apply(this.apply(x));
    }

}
