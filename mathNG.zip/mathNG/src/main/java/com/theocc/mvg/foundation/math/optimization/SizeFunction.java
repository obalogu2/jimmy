/**
 * 
 */
package com.theocc.mvg.foundation.math.optimization;

import com.theocc.mvg.foundation.math.TriFunction;

/**
 * 
 * In Bracketing Search Methods for finding the minimum of a function f(x) in a given interval, the Fibonacci search requires
 * the size of the iteration to be calculated using the interval and a tolerance.
 * 
 * The implementation of this interface is a function that takes the interval and tolerance and return the size of the iteration
 * 
 * @author Owner
 *
 */
interface SizeFunction extends TriFunction<double[], double[], Double, Integer>{

    /********************************************
     *
     * THIS IS NOT AN EXPOSED INTERFACE IT IS USED
     * INTERNALLY BY THE FIBONACCI METHOD TO DETERMINE
     * THE SIZE OF THE ITERATION
     *
     ********************************************/
}
