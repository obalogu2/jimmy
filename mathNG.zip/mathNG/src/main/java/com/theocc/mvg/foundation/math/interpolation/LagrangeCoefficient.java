package com.theocc.mvg.foundation.math.interpolation;

/**
 *
 * Created by Owner on 5/30/16.
 */
@FunctionalInterface
interface LagrangeCoefficient {

    /********************************************
     *
     * THIS IS NOT AN EXPOSED INTERFACE IT IS USED
     * INTERNALLY TO CREATE THE LAGRANGE POLYNOMIAL
     * COEFFICIENT
     *
     ********************************************/

    double apply(double[] abscissas, double x, int k);


}
