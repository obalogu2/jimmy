package com.theocc.mvg.foundation.math.interpolation;

/**
 * Created by Owner on 5/30/16.
 */
class LagrangeCoefficientImpl implements LagrangeCoefficient{

    @Override
    public double apply(double[] abscissas, double x, int k) {

        if( abscissas == null || abscissas.length < 2){
            throw new IllegalArgumentException(" The minimum points is 2");
        }

        if( k < 0 || k >= abscissas.length ) {
            throw new IllegalArgumentException(" Invalid apply for k");
        }

        int n = abscissas.length - 1;
        double numerator = 1.0;
        double denominator = 1.0;

        for( int i = 0; i <= n; i++ ){
            if( i != k ){
                numerator *= x  -  abscissas[i];
                denominator *= abscissas[k] - abscissas[i];
            }
        }
        return numerator/denominator;
    }
}
