package com.theocc.mvg.foundation.math.interpolation;

import com.theocc.mvg.foundation.math.UnivariateFunction;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.function.DoubleFunction;
import java.util.function.ToDoubleBiFunction;
import java.util.stream.Collectors;

/**
 * Created by Owner on 5/30/16.
 */
public final class InterpolationFactory {

    private static final LagrangeCoefficient lagrangeCoeff = new LagrangeCoefficientImpl();

    private static final Comparator<double[]> euclideanComparator = (double[] p1, double[] p2) -> {
        double diff = p1[0] - p2[0];
        return diff == 0 ? 0 : diff < 0 ? -1 : 1;
    };

    private static final ToDoubleBiFunction<double[], double[]> slopeFunction = (double[] t, double[] u) -> (u[1] - t[1])/(u[0] - t[0]);

    private InterpolationFactory(){}

    public static Comparator<double[]> getEuclideanComparator() {
        return euclideanComparator;
    }

    public static ToDoubleBiFunction<double[], double[]> getSlopeFunction() {
        return slopeFunction;
    }

    public static LinearSpline linearSpline(double[][] points) {

        Arrays.sort(points, euclideanComparator);

        return (double arg) -> {

            ToDoubleBiFunction<double[], double[]> evaluator = (double[] t, double[] u) -> t[1] + slopeFunction.applyAsDouble(t, u) * (arg - t[0]);

            int index = Arrays.binarySearch(points, new double[]{arg}, euclideanComparator);

            if (index < 0) {
                index = -index - 2;
            }

            if (index >= points.length) {
                index--;
            }

            return evaluator.applyAsDouble(points[index], points[index + 1]);
        };

    }

    public static LagrangePolynomial lagrangePolynomial(final double[] abscissas, final DoubleFunction<Double> objectiveFunction){

        List<double[]> coordinate = Arrays.stream(abscissas)
                .mapToObj(value -> new double[]{value, objectiveFunction.apply(value)})
                .collect(Collectors.toList());

        Arrays.sort(abscissas);
        return ( double x ) -> {

            double sum = 0d;
            for( int i = 0; i < abscissas.length; i++ ){
                sum += objectiveFunction.apply(abscissas[i]) * lagrangeCoeff.apply(abscissas,x,i );

            }
            return sum;
        };
    }

    public static LagrangePolynomial lagrangePolynomial(final double[] abscissas, final UnivariateFunction objectiveFunction){

        Arrays.sort(abscissas);

        return( double x ) -> {

            double sum = 0d;
            for( int i = 0; i < abscissas.length; i++ ){
                sum += objectiveFunction.apply(abscissas[i]) * lagrangeCoeff.apply(abscissas,x,i );

            }
            return sum;
        };
    }

    public static LagrangePolynomial lagrangePolynomial(final double[][] euclideanPoint){

        Arrays.sort(euclideanPoint, euclideanComparator);
        double[] abscissa = new double[euclideanPoint.length];
        for( int i = 0; i < euclideanPoint.length; i++){
            abscissa[i] = euclideanPoint[i][0];
        }

        LagrangePolynomial lagrangePolynomial = ( double x ) -> {

            double sum = 0d;
            for( int i = 0; i < abscissa.length; i++ ){
                sum += euclideanPoint[i][1] * lagrangeCoeff.apply(abscissa,x,i );

            }
            return sum;
        };

        return lagrangePolynomial;
    }
}
