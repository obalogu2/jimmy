package com.theocc.mvg.foundation.math.optimization;

import com.theocc.mvg.foundation.math.UnivariateFunction;

/**
 * Created by Owner on 5/31/16.
 */
final class QuadraticSearchImpl implements QuadraticSearch {
    @Override
    public double apply(UnivariateFunction f, double[] interval, double epsilon) {

        double h = interval[1] - interval[0] + 500;
        double[] bracket = null;
        double y0;
        double y1;
        double y2;

        double hMin ;
        double pMin;
        double yMin;

        do {

            bracket = bracketingTheMinimum(f, interval, bracket == null ? interval[0] : bracket[0],  h);
            y0 = f.apply(bracket[0]);
            y1 = f.apply(bracket[1]);
            y2 = f.apply(bracket[2]);
            h = bracket[3];

            hMin = h*(4*y1  - 3*y0 - y2)/(4*y1  - 2*y0 - 2*y2);
            pMin = bracket[0] + hMin;
            yMin = f.apply(pMin);

            h = hMin;
            bracket[0] = pMin;

        }while ( Math.abs(y0 - yMin) > epsilon || Math.abs(y1 - yMin) > epsilon ||Math.abs(y2 - yMin) > epsilon );

        return pMin;
    }
}
