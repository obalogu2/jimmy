package com.theocc.mvg.foundation.math;

/**
 * Created by Owner on 5/29/16.
 */
@FunctionalInterface
public interface TriFunction<T,U,V,R> {
    R apply(T t, U u, V v);
}
