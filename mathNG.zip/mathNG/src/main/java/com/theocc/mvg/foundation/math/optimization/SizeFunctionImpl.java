/**
 * 
 */
package com.theocc.mvg.foundation.math.optimization;

import java.util.Arrays;

/**
 * @author Owner
 *
 */
final class SizeFunctionImpl implements SizeFunction {

    /********************************************
     *
     * THIS IS NOT AN EXPOSED INTERFACE
     *
     * IMPLEMENTATION
     *
     ********************************************/
	public SizeFunctionImpl(){
	}

	/* (non-Javadoc)
	 * @see java.util.function.ToIntBiFunction#applyAsInt(java.lang.Object, java.lang.Object)
	 */
	@Override
	public Integer apply(double[] fibonaccis, double[] interval, Double tolerance) {
		
		if( interval == null || interval.length != 2 || interval[0] >= interval[1]) 
			throw new IllegalArgumentException("The interval must be of size 2 where interval[0] < interval[1] ");
		
		
		long fibonacci = (long) ((interval[1]- interval[0])/tolerance);
		int index = Arrays.binarySearch(fibonaccis, fibonacci);
		index = index < 0 ? -index - 1 : index;
		
		return index;
	}
}
