package com.theocc.mvg.foundation.math.optimization;

import com.theocc.mvg.foundation.math.UnivariateFunction;

/**
 * Created by Owner on 5/31/16.
 */
@FunctionalInterface
public interface QuadraticSearch {
    public double apply(UnivariateFunction f, double[] interval, double epsilon);

    public default double[] bracketingTheMinimum(UnivariateFunction f, double[] interval, double p0, double h){

        if( interval.length != 2 || interval[0] >= interval[1]  ){
            throw new IllegalArgumentException(String.format("Invalid interval [%1$f, %2$f]", interval[0], interval[1]));
        }

        double[] p = new double[4];
        double diff =  interval[1] - interval[0];
        h = interval[0] + h >= interval[1]? diff/4 : h;
        p[0] = p0 < interval[0] || p0 > interval[1]? interval[0] : p0;
        p[1] = p[0] + h;
        p[2] = p[1] + h;
        boolean done = false;

        while( !done ){
            double fp0 =  f.apply(p[0]);
            double fp1 =  f.apply(p[1]);
            double fp2 =  f.apply(p[2]);

            if( fp0 > fp1 && fp1 < fp2 ){
                done = true;

            }else if( fp0 > fp1 && fp1 > fp2 ){
                h*=2;
                p[1] = p[0] + h;
                p[2] = p[1] + h;

            }else if( fp0 <= fp1  ){
                h/=2;
                p[1] = p[0] + h;
                p[2] = p[1] + h;
            }
        }

        p[3] = h;
        return p;
    }
}
