/**
 * 
 */
package com.theocc.mvg.foundation.math.optimization;

import com.theocc.mvg.foundation.math.UnivariateFunction;

import java.util.function.DoubleFunction;
/**
 * @author Owner
 *
 */
@FunctionalInterface
public interface FibonacciSearchMethod {
	double apply(UnivariateFunction objectiveFunction, double[] interval, double tolerance, double disConstant);
}
