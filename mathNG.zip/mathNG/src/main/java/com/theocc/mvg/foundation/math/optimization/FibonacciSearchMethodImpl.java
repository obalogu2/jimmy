/**
 * 
 */
package com.theocc.mvg.foundation.math.optimization;


import com.theocc.mvg.foundation.math.UnivariateFunction;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.function.DoubleFunction;

/**
 * @author Owner
 *
 */
final class FibonacciSearchMethodImpl implements FibonacciSearchMethod {

    private static final Logger LOG = LogManager.getLogger(FibonacciSearchMethod.class);

	private double[] arrOfFibonacci;
    private final SizeFunction sizeFunction;
	
	FibonacciSearchMethodImpl(int sizeOfFibonacciArray, SizeFunction sizeFunction){

        sizeOfFibonacciArray = sizeOfFibonacciArray < 100 ? 100 : sizeOfFibonacciArray;
        initFibonacci(sizeOfFibonacciArray);
        this.sizeFunction = sizeFunction;

	}

    private void initFibonacci(int size){

        arrOfFibonacci = new double[size];
        arrOfFibonacci[0] = 0;
        arrOfFibonacci[1] = 1;

        for( int i = 2; i < 100; i++ ){
            arrOfFibonacci[i] = arrOfFibonacci[i-1] + arrOfFibonacci[i-2];
        }

    }

	/* (non-Javadoc)
	 * @see com.theocc.mvg.foundation.math.optimization.FibonacciSearchMethod#apply(java.util.function.Function, double[], double, double)
	 */
	@Override
	public double apply(UnivariateFunction f, double[] interval, double tolerance, double disConstant) {
		
		int n = sizeFunction.apply(arrOfFibonacci, interval, tolerance);

        //This safeguard a situation where the size of the iteration is greater than the
        //predefined fibonacci numbers
        if( n > arrOfFibonacci.length  ) {
            initFibonacci(n+5);
        }
		InteriorPoint cFunc = (double a, double b, int k) -> a + ( 1 - arrOfFibonacci[n - k - 1]/ arrOfFibonacci[n - k])*(b -a);
		InteriorPoint dFunc = (double a, double b, int k) -> a + (arrOfFibonacci[n - k - 1]/ arrOfFibonacci[n - k])*(b -a);
		
		InteriorPoint cFuncUsingDisConstant = (double a, double b, int k) -> a + (0.5 - disConstant)*(b - a);
		InteriorPoint dFuncUsingDisConstant = (double a, double b, int k) -> a + (0.5 + disConstant)*(b - a);

		int k = 0;
		double[] a = new double[n];
		double[] b = new double[n];
		double[] c = new double[n];
		double[] d = new double[n];
		
		a[k] = interval[0];
		b[k] = interval[1];
		
		c[k] = cFunc.compute(a[k], b[k], k);
		d[k] = dFunc.compute(a[k], b[k], k);
		
		while( b[k] - a[k] > tolerance && k < n ){
			
			if( f.apply(c[k]) <= f.apply(d[k])){
				
				//Left shift on the x-axis
				a[k+1] = a[k];
				b[k+1] = d[k];
				d[k+1] = c[k];
				
				if( Math.abs((arrOfFibonacci[n - k - 1]/ arrOfFibonacci[n - k]) - 0.5) < 0.000000001 ){
					c[k+1] = cFuncUsingDisConstant.compute(a[k+1], b[k+1], k+1);
				}else{
					c[k+1] = cFunc.compute(a[k+1], b[k+1], k+1);
				}
			}else{
				
				//right shift on the x-axis
				a[k+1] = c[k];
				b[k+1] = b[k];
				c[k+1] = d[k];
				
				if( Math.abs((arrOfFibonacci[n - k - 1]/ arrOfFibonacci[n - k]) - 0.5) < 0.000000001 ){
					d[k+1] = dFuncUsingDisConstant.compute(a[k+1], b[k+1], k+1);
				}else{
					d[k+1] = dFunc.compute(a[k+1], b[k+1], k+1);
				}
			}
			k++;
		}

        k = k == n ? k - 1 : k;
        System.out.println(LOG.getLevel());
        if( LOG.getLevel() == Level.INFO ){
            StringBuilder stringBuilder = new StringBuilder();
            for( int i = 0; i <= k; i++){
                stringBuilder.append(i)
                        .append("\t").append(a[i])
                        .append("\t").append(c[i])
                        .append("\t").append(d[i])
                        .append("\t").append(b[i]).append("\n");

            }
            LOG.log(Level.INFO, stringBuilder);
        }

		return (b[k] + a[k])/2;
	}

	@FunctionalInterface
	private interface InteriorPoint{
		double compute(double a, double b, int index);		
	}
	
}
