package com.theocc.mvg.foundation.math.interpolation;

import com.theocc.mvg.foundation.math.UnivariateFunction;

/**
 * Created by Owner on 5/30/16.
 */
@FunctionalInterface
public interface LagrangePolynomial extends UnivariateFunction {
}
