package com.theocc.mvg.foundation.math.optimization;

/**
 * Created by Owner on 5/29/16.
 */
public final class OptimizationFactory {

    private static SizeFunction sizeFunction;

    static{
        sizeFunction = new SizeFunctionImpl();
    }
    private OptimizationFactory(){}

    public static FibonacciSearchMethod createFibonacciSearchMethod(int sizeOfFibonacciArray){
         return new FibonacciSearchMethodImpl(sizeOfFibonacciArray, sizeFunction);
    }

    public static QuadraticSearch createQuadraticSearch(){
        return new QuadraticSearchImpl();
    }
}
