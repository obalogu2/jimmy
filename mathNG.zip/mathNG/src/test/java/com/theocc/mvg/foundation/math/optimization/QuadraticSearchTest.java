package com.theocc.mvg.foundation.math.optimization;

import com.theocc.mvg.foundation.math.UnivariateFunction;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.function.DoubleFunction;

import static org.junit.Assert.*;

public class QuadraticSearchTest {

    private  UnivariateFunction objectiveFunc = (double x) -> Math.pow(x,2) - Math.sin(x);
    @Before
    public void setUp() throws Exception {

    }

    @After
    public void tearDown() throws Exception {

    }

    @Test
    public void testApply() throws Exception {
        double[] interval = new double[]{0,1};
        double h = interval[1] - interval[0] +500;

        objectiveFunc = (double x) -> Math.pow(x,2) - Math.sin(x);
        double tolerance = Math.pow(10, -4);
        FibonacciSearchMethod fibMethod = OptimizationFactory.createFibonacciSearchMethod(100);
        double abscissa = fibMethod.apply(objectiveFunc, interval, tolerance, 0.01);
        System.out.println(abscissa);

        QuadraticSearch quadraticSearch = OptimizationFactory.createQuadraticSearch();
        abscissa = quadraticSearch.apply(objectiveFunc, interval, 0.0000000000001);
        System.out.println(abscissa);
    }

    @Test
    public void testBracketingTheMinimum() throws Exception {
        double[] interval = new double[]{0,1};
        double h = interval[1] - interval[0] +500;

        objectiveFunc = (double x) -> Math.pow(x,2) - Math.sin(x);
        double tolerance = Math.pow(10, -4);
        FibonacciSearchMethod fibMethod = OptimizationFactory.createFibonacciSearchMethod(100);
        double abscissa = fibMethod.apply(objectiveFunc, interval, tolerance, 0.01);
        System.out.println(abscissa);

        QuadraticSearch quadraticSearch = OptimizationFactory.createQuadraticSearch();
        double[] bracket = quadraticSearch.bracketingTheMinimum(objectiveFunc, interval, interval[0], h);
        System.out.println(Arrays.toString(bracket));
    }
}