package com.theocc.mvg.foundation.math.optimization;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.function.DoubleFunction;

import com.theocc.mvg.foundation.math.UnivariateFunction;
import org.junit.Test;

public class FibonacciSearchMethodImplTest {

	@Test
	public void testApply() {

		FibonacciSearchMethod fibMethod = OptimizationFactory.createFibonacciSearchMethod(100);
        assertNotNull("", fibMethod);

        UnivariateFunction objectiveFunc = (double x) -> Math.pow(x,2) - Math.sin(x);
		double tolerance = Math.pow(10, -4);
		double abscissa = fibMethod.apply(objectiveFunc, new double[]{0, 1}, tolerance, 0.01);

        //Testing values
        assertTrue("", Math.abs(abscissa - 0.4501645)  <= 0.000001 );
        assertTrue("", Math.abs(objectiveFunc.apply(abscissa) - (-0.2324655747108840)) <= 0.000001);

        //Testing assumptions
        DoubleFunction<Double> derivativeOfObjectiveFunc = (double x) -> 2*x - Math.cos(x);
        double[] b4Abscissa  = new double[5];
        double[] afterAbscissa  = new double[5];
        double delta = (1d-0d)/40d;

        //Generate random values
        for( int i = 0; i < 4;  i++){
            int h = (int) (Math.random() * 10) + 1;
            b4Abscissa[i] = abscissa - h*delta;
            assertTrue("", 0d  < b4Abscissa[i]);
            afterAbscissa[i] = abscissa + h*delta;
            assertTrue("", afterAbscissa[i] < 1);
        }

        b4Abscissa[4]= delta;
        afterAbscissa[4] = 1 - delta;

        //Test the random values
        for( int i = 0; i < 5; i++ ){
            assertTrue("", derivativeOfObjectiveFunc.apply(b4Abscissa[i]) < 0  );
            assertTrue("", derivativeOfObjectiveFunc.apply(afterAbscissa[i]) > 0  );
        }
	}

}
