/**
 * 
 */
package com.theocc.mvg.foundation.math.optimization;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

/**
 * @author Owner
 *
 */
public class SizeFunctionImplTest {

	/**
	 * Test method for {@link com.theocc.mvg.foundation.math.optimization.SizeFunctionImpl#apply(double[] , double[] , Double )}.
	 */
	@Test
	public void testApplyAsInt() {
		double[] fibonaccis = new double[100];
		fibonaccis[0] = 0;
		fibonaccis[1] = 1;
		
		for( int i = 2; i < 100; i++ ){
			fibonaccis[i] = fibonaccis[i-1] + fibonaccis[i-2];
		}
		SizeFunction iterationSize = new SizeFunctionImpl();
		int n = iterationSize.apply(fibonaccis, new double[]{0,1}, Math.pow(10, -4) );
		assertEquals("", 21, n);
		System.out.println(n);
		
	}

}
