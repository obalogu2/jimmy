package com.theocc.mvg.foundation.math.interpolation;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import java.util.Arrays;
import java.util.function.ToDoubleBiFunction;

import static org.junit.Assert.assertTrue;

public class InterpolationFactoryTest {

    private double[][] tester;

    /**
     * @throws java.lang.Exception
     */
    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
    }

    /**
     * @throws java.lang.Exception
     */
    @AfterClass
    public static void tearDownAfterClass() throws Exception {
    }

    /**
     * @throws java.lang.Exception
     */
    @Before
    public void setUp() throws Exception {
        //tester = new double[][]{{0.1,0.01},{2.5,6.25},{4.2,1.74},{1.3,1.69},{9.5,90.25},{2.5,6.25},{4.6,21.16},{2.8,7.84},{0.12,0.0144},{3.69,13.6161}};
        tester = new double[][]{{1,3.0},{2,4.0},{3,4.6},{4,5.0},{5,5.3}};


    }

    /**
     * @throws java.lang.Exception
     */
    @After
    public void tearDown() throws Exception {
    }

    /**
     * Test method for {@link com.theocc.mvg.foundation.math.interpolation.InterpolationFactory#getEuclideanComparator()}.
     */
    @Test
    public void testGetEuclideanComparator() {
        System.out.println(Arrays.toString(map(tester)));
        Arrays.sort(tester, InterpolationFactory.getEuclideanComparator());
        for( int i = 0; i < tester.length -1; i++){
            assertTrue(String.format("%1$f <= %2$f", tester[i][0],tester[i+1][0]), tester[i][0] <= tester[i+1][0]);
        }
        System.out.println(Arrays.toString(map(tester)));

    }

    /**
     * Test method for {@link com.theocc.mvg.foundation.math.interpolation.InterpolationFactory#getSlopeFunction()}.
     */
    @Test
    public void testGetSlopeFunction() {

        double[] point1 = new double[]{0.1,0.01};
        double[] point2 = new double[]{2.5,6.25};

        ToDoubleBiFunction<double[], double[]> slope = InterpolationFactory.getSlopeFunction();
        double m = slope.applyAsDouble(point1, point2);
        System.out.println(m);
    }

    /**
     * Test method for {@link com.theocc.mvg.foundation.math.interpolation.InterpolationFactory#linearSpline(double[][])}.
     */
    @Test
    public void testLinearSpline() {
        LinearSpline linearSpline = InterpolationFactory.linearSpline(tester);
        System.out.println(linearSpline.apply(2.9));

        double[][] t = new double[101][];
        t[0] = new double[2];
        t[0][0] = 0.1;
        t[0][1] = Math.pow(t[0][0],2);

        for( int i = 1; i < t.length; i++ ){
            t[i] = new double[2];
            t[i][0] = t[i-1][0] + 0.094;
            t[i][1] = Math.pow(t[i][0],2);
        }

        System.out.println(Arrays.toString(map(t)));
        linearSpline = InterpolationFactory.linearSpline(t);
        System.out.println(linearSpline.apply(2.9));
    }

    private static String[] map(double[][] array){
        return Arrays.stream(array).map((double[] value) -> String.format("(%1$f, %2$f)", value[0], value[1])).toArray(String[]::new);

    }

    @Test
    public void testLagrangePolynomialDoubleFunction(){
        double[] abscissas = new double[]{2, 2.5,4};
        LagrangePolynomial lagrangePolynomial = InterpolationFactory.lagrangePolynomial(abscissas, (double value) -> new Double(1d/value) );
        System.out.println("LAG " + lagrangePolynomial.apply(3d));
    }

    @Test
    public void testLagrangePolynomialUnivariateFunction(){
        double[] abscissas = new double[]{2, 2.5,4};
        LagrangePolynomial lagrangePolynomial = InterpolationFactory.lagrangePolynomial(abscissas, (double value) -> 1d/value );
        System.out.println("LAG " + lagrangePolynomial.apply(3d));
    }

}