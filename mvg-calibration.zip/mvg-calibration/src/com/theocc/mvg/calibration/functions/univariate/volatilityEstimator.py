
import math
import numpy as np
import pandas as pd
import scipy.optimize as opt

from com.theocc.mvg.calibration.functions.models import garch


def mle_wrt_sigma_sqr(rf_returns, sigma_sqr, dof, sample_mean, t):

    """
    This is function is the implementation of formula 4.32 in the QRM Stans Methodology

    The function is equivalent to the partial derivative of the objective function with respect to
    sigma_sqr of t

    :param rf_returns:      An Array(Series) log return
    :param sigma_sqr:       This an array holding the Garch(1,1) function value, since the garch function is recursive
    :param dof:             The fitted degree of freedom for the particular risk factor
    :param sample_mean:     The sample mean of the series
    :param t:               This is the numerical index (Particular Risk Factor Log return)
    :return:
    """
    distance_sqr = (rf_returns[t] - sample_mean)**2.0
    return (1.0/sigma_sqr[t])*(1.0 - ((dof + 1.0) * distance_sqr))/((sigma_sqr[t]*(dof - 2.0)) + distance_sqr)


def objective_function(alpha_beta_arr, rf_returns, dof, sigma_LR, historical_mean, risk_factor=None ):

    """
    The objective function (formula 4.30), please read the stans documentation to understand the reason why the other
    part of the objective function is omitted


    :param alpha_beta_arr:      Array of alpha beta value
    :param rf_returns:          The log returns
    :param dof:
    :param sigma_LR:
    :param historical_mean:
    :param risk_factor
    :return:
    """

    alpha = alpha_beta_arr[0]
    beta = alpha_beta_arr[1]
    obj_sum = 0.0

    n = rf_returns.size
    _n_ = n + 1
    sigma_sqr = np.zeros(_n_)
    sigma_sqr[0] = sigma_LR

    for t in list(range(1, _n_)):
        sigma_sqr[t] = garch(rf_returns, alpha, beta, sigma_sqr, historical_mean, t, n)
        val_2 = 1.0 + (rf_returns[t - 1] - historical_mean)**2.0/(sigma_sqr[t] * (dof - 2.0))
        obj_sum += math.log(sigma_sqr[t]) + (dof + 1.0)* math.log(val_2)

    return 0.5 * obj_sum


def mle_wrt_alpha(rf_returns, alpha, beta, dof, sigma_LR, historical_mean, risk_factor=None):

    """
    This is equation 4.31 in the QRM Stans

    :param rf_returns:
    :param alpha:
    :param beta:
    :param dof:
    :param sigma_LR:
    :param historical_mean:
    :param risk_factor:
    :return:
    """

    business_date = rf_returns.size
    _n_ = business_date + 1
    sigma_sqr = np.zeros(_n_)

    # The initial value for sigma_sqr is the historical variance
    sigma_sqr[0] = sigma_LR
    garch_wrt_alpha = np.zeros(_n_)

    # the initial value of derivative of garch function with respect to alpha is zero
    garch_wrt_alpha[0] = 0.0
    value = 0.0

    # The index ranges from 1..500
    for t in list(range(1, _n_)):

        # DO NOT SUBTRACT 1 FROM t ARGUMENT IN garch function
        sigma_sqr[t] = garch(rf_returns, alpha, beta, sigma_sqr, historical_mean, t, business_date)

        garch_wrt_alpha[t] = -1.0 * sigma_sqr[0] + (rf_returns[t - 1] - historical_mean) ** 2 + beta * garch_wrt_alpha[t - 1]

        # SUBTRACT 1 FROM t BECAUSE WE ARE COMPUTING THE MLE OF CURRENT
        value += mle_wrt_sigma_sqr(rf_returns, sigma_sqr, dof, historical_mean, t - 1) * garch_wrt_alpha[t]

    return 0.5 * value


def mle_wrt_beta(rf_returns, alpha, beta, dof, sigma_LR, historical_mean, risk_factor=None):

    """
    The index of the summation should be paid more attention because this lag-1 Garch

    :param rf_returns:
    :param alpha:
    :param beta:
    :param k:
    :param dof:
    :param sigma_LR:
    :param historical_mean:
    :param risk_factor:
    :return:
    """

    business_date = rf_returns.size
    _n_ = business_date + 1

    sigma_sqr = np.zeros(_n_)
    sigma_sqr[0] = sigma_LR
    garch_wrt_beta = np.zeros(_n_)
    garch_wrt_beta[0] = 0.0
    value = 0.0

    # The index ranges from 1..500
    for t in list(range(1, _n_)):

        # DO NOT SUBTRACT 1 FROM t ARGUMENT IN garch function
        sigma_sqr[t] = garch(rf_returns, alpha, beta, sigma_sqr, historical_mean, t, business_date)

        garch_wrt_beta[t] = -1.0 * sigma_sqr[0] + sigma_sqr[t - 1] + beta * garch_wrt_beta[t - 1]

        # SUBTRACT 1 FROM t BECAUSE WE ARE COMPUTING THE MLE OF CURRENT
        value += mle_wrt_sigma_sqr(rf_returns, sigma_sqr, dof, historical_mean, t - 1) * garch_wrt_beta[t]

    return 0.5 * value


def objective_prime(x, rf_transform_return, nu, rf_var, rf_mean, risk_factor=None):
    return np.array([mle_wrt_alpha(rf_transform_return, x[0], x[1], nu, rf_var, rf_mean, risk_factor),
                     mle_wrt_beta(rf_transform_return, x[0], x[1], nu, rf_var, rf_mean, risk_factor)])


def garch_fit(standardized_time_series, dof, alpha_min, alpha_max, beta_min, beta_max, horizon, _dir_=None):

    dof_copy = dof.copy()

    # Convert the mean array to matrix of n by m where the value in the column are identical
    dof_mat = dof_copy.as_matrix()
    dof_mat.shape = (1, standardized_time_series.shape[1])
    dof_mat = np.ones((standardized_time_series.shape[0], 1)) * dof_mat
    dof_mat = pd.DataFrame(dof_mat, index=standardized_time_series.index, columns=standardized_time_series.columns)
    dof_mat = dof_mat.applymap(lambda x: (float(x)/(float(x) - 2.0))**0.5)

    if _dir_ is not None:
        dof_mat.to_csv("%s\\dof_mat.csv" % _dir_)

    transformed_time_series = dof_mat.combine(standardized_time_series, lambda v1, v2: v1*v2)

    if _dir_ is not None:
        transformed_time_series.to_csv("%s\\transformed_time_series.csv" % _dir_)

    transformed_time_series = transformed_time_series.T
    rf_names = transformed_time_series.index

    parameter_data_frame = pd.DataFrame(index=rf_names, columns=['dof', 'alpha', 'beta', 'validation', 'imp-vol'])
    alpha_bound = (alpha_min, 0.999999999897889 * alpha_max)
    beta_bound = (beta_min, beta_max)
    alpha_zero = 0.95 * alpha_max
    beta_zero = 0.95 * (1 - alpha_zero - 0.01)

    for rf in rf_names:

        rf_transform_return = transformed_time_series.loc[rf]
        rf_mean = rf_transform_return.mean()
        rf_var = rf_transform_return.var()

        nu_scale = dof[rf]/(dof[rf] - 2.0)

        cons = ({'type': 'ineq',
                 'fun': lambda x: np.array([0.99 - nu_scale * x[0] - x[1]]),
                 'jac': lambda x: np.array([-1.0 * nu_scale, -1.0])
                 }
                )

        res = opt.minimize(objective_function, np.array([alpha_zero, beta_zero]), args=(rf_transform_return, dof[rf], rf_var, rf_mean),
                            jac=objective_prime, constraints=cons, method='SLSQP', bounds=[alpha_bound, beta_bound],
                           options={'disp': True})

        alpha = float(res.x[0])
        beta = float(res.x[1])
        """
        res = opt.fmin_l_bfgs_b(objective_function, np.array([0.038, 0.952]), fprime=objective_prime, args=(rf_transform_return, dof[rf], rf_var, rf_mean, rf),
                        bounds=[alpha_bound, beta_bound], maxls=60)

        alpha = float(res[0][0])
        beta = float(res[0][1])
        """
        parameter_data_frame.loc[rf] = [dof[rf], alpha, beta, (alpha + beta) < 1.0, 22]

    return parameter_data_frame
