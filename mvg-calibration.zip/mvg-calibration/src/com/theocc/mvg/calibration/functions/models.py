
import numpy as np


def garch(log_returns, alpha, beta, sigma_sqr, sample_mean, t, business_days):
    return (1.0 - alpha - beta)*sigma_sqr[0] + alpha*(log_returns[business_days - t] - sample_mean)**2.0 + beta*sigma_sqr[t - 1]


def volatility_forecast(log_returns, alpha, beta, sample_mean, sample_sigma):

    sigma_sqr = np.zeros(log_returns.size)
    sigma_sqr[0] = sample_sigma

    n = log_returns.size

    for t in list(range(1, n)):
        sigma_sqr[t] = garch(log_returns, alpha, beta, sigma_sqr, sample_mean, t, n)

    return garch(log_returns, alpha, beta, sigma_sqr, sample_mean, n, n)
