
import numpy as np
import pandas as pd
from scipy.stats import t

from math import log


def anderson_darling(data, dist, cdf_args):

    """
    The General Anderson Darling loops from 1 to N, I change that to 0 to N-1, since most arrays index start from
    0 and end at N - 1, where N is the length of the array

    :param data:    The data must be a pandas series or a numpy array. Please remember the python array is not
                    homogeneous, using it with python array might yield error or something strange
    :param dist:     This is the cumulative distribution function, if the function require more argument a wrapper
                    function must be used, or let the distribution be an Higher order function HOF
    :param cdf_args The distribution argument
    :return:        The function return Anderson Darling statistics
    """

    s_data = np.sort(data,kind='mergesort')
    n = len(s_data)
    s = 0

    cdf = None
    if dist == 'Student-T':
        cdf = t.cdf

    for k in range(0, n, 1):
        m = n - 1
        _cdf_k = cdf(s_data[k],cdf_args[0])
        _cdf_n_k = cdf(s_data[m-k],cdf_args[0])

        s += (2.0*k + 1.0)*(log(_cdf_k) + log(1.0 - _cdf_n_k))

    return (-1.0)*n - float(s)/float(n)


def standardized(data_frame, mean_df=None, std_df=None, _dir_=None):

    """
    The is function standardized the data_frame with n by m dimension using matrix operation
    (X-U)*E^(-1)

    :param data_frame:  The original data source
    :param func:        This is a scaling function
    :param mean_df:     The mean of each column for this data_frame argument
    :param std_df:      The standard deviation for this data_frame argument
    :param _dir_:       The directory where to put all serialize data for debugging purposes
    :return:            it return a standardized data frame of size identical to the input data frame(data_frame0
    """

    # if the mean or std argument are not provided compute mean and/or std
    if mean_df is None:
        mean_df = data_frame.mean(axis=0)

    if std_df is None:
        std_df = data_frame.std(axis=0)

    # Get the length of the mean must equal to (m)
    # size = len(mean_df)
    size = data_frame.shape[1]
    if size != mean_df.shape[0] and size != std_df.shape[0]:
        raise ValueError('Expecting %d, receive %d or %d' %(size, mean_df.shape[0], std_df.shape[0]))

    # Get the length of the data_frame must be equal to (n)
    # data_len = len(data_frame.index)
    data_len = data_frame.shape[0]

    # Convert the mean array to matrix of n by m where the value in the column are identical
    mean_mat = mean_df.as_matrix()
    mean_mat.shape = (1,size)
    mean_mat = np.ones((data_len,1)) * mean_mat

    if _dir_ is not None:
        np.savetxt("%s\\mean_mat.csv" % _dir_, mean_mat,delimiter=',', newline='\n')

    # Perform X - U
    diff = data_frame.as_matrix() - mean_mat

    # Convert the std array to a diagonal matrix with the standard deviation(inverse) on the diagonal, hence E^(-1)
    std_mat = std_df.as_matrix()

    if _dir_ is not None:
        np.savetxt("%s\\pre-std_mat.csv" % _dir_, std_mat,delimiter=',',newline='\n')

    std_mat.shape = (size,1)
    std_mat = (float(1)/std_mat) * np.identity(size)
    if _dir_ is not None:
        np.savetxt("%s\\post-std_mat.csv" % _dir_, std_mat,delimiter=',',newline='\n')

    # Perform the dot product or matrix multiplication
    s = np.dot(diff, std_mat)

    if _dir_ is not None:
        np.savetxt("%s\\s_dot.csv" % _dir_,std_mat,delimiter=',',newline='\n')

    # Return a data frame
    return pd.DataFrame(s, index=data_frame.index, columns=data_frame.columns)


def scale_to_nu(data_frame, nu):

    """

    The Variance of Student Distribution is nu/(nu-2), the data frame has be standardized with (x-mu)/sigma, Since we are gusesing the variance
    we need to scale the standardized returns

    :param data_frame:  The data grid that needed to be scaled
    :param nu:          The nu(dof)
    :return:            The scaled data frame

    """
    nu = float(nu)
    scale_nu = (nu/(nu - 2.0))**0.5
    nu_data_frame = data_frame.applymap(lambda x:x*scale_nu)
    return nu_data_frame


def demean(data_series):

    """

    :param data_series:
    :return: a demean data_series
    """

    mean_value = data_series.mean()
    return data_series.apply(lambda x: x - mean_value)
