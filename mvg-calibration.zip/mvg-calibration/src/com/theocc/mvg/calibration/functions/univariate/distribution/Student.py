import math


def i_beta(w, a, b):

    beta = math.exp(math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b) + a * math.log(w) + b * math.log(1 - w))
    if w < (a+1.0)/(a + b + 2.0) :
        return beta * continued_fraction(a, b, w)/a

    return 1.0 - beta*continued_fraction(b, a, 1-w)/b


def continued_fraction(a, b, x, e=3.0e-7, small=1.0e-30, max_iter=100):

    qab = a + b + 0.0
    qap = a + 1.0
    qam = a - 1.0
    done = -1
    m = 1
    c = 1.0
    d = 1.0 - qab * x / qap

    if math.fabs(d) < small:
        d = small

    d = 1.0/d
    h = d

    while m < max_iter and done < 0:
        m_2 = 2 * m
        a_a = m * (b - m) * x / float((qam + m_2) * (a + m_2))
        d = 1.0 + a_a * d
        if math.fabs(d) < small:
            d=small

        c = 1.0 + a_a / c
        if  math.fabs(c) < small:
            c=small

        d = 1.0 / d
        h *= d * c
        a_a = -(a + m) * (qab + m) * x / ((a + m_2) * (qap + m_2))
        d = 1.0 + a_a * d
        if math.fabs(d) < small:
            d = small

        c = 1.0 + a_a / c
        if math.fabs(c) < small:
            c = small

        d = 1.0 / d
        delta = d * c
        h *= delta

        if math.fabs(delta - 1.0) < e:
            done = 1
        m += 1

        if m >= max_iter:
            return -1 * float('inf')

    return h


def cdf(nu, use_default=False):
    pi_inv = 1 / math.pi
    sqrt_3 = math.sqrt(3)
    sqrt_5 = math.sqrt(5)

    def _t_default(z):

        if z == 0.0:
            return 0.5
        else:
            i_bt = i_beta(float(nu)/float(nu + z*z), 0.5*nu,0.5)
            if z < 0.0:
                return 0.5*i_bt
            else:
                return 1 - 0.5*i_bt

    funcs = [None,
             lambda z: 0.5 + pi_inv * math.atan(z),
             lambda z: 0.5 + z / (2 * math.sqrt((z ** 2 + 2))),
             lambda z: 0.5 + pi_inv * math.atan(z / sqrt_3) + float(sqrt_3 * z) / float(math.pi * (z ** 2 + 3)),
             lambda z: 0.5 + 0.5 * ((z*(z ** 2 + 6)) / ((z ** 2 + 4) ** 1.5)),
             lambda z: 0.5 + pi_inv * math.atan(z / sqrt_5) + float(sqrt_5 * (3 * z ** 2 + 25)) / float(3 * math.pi * (z ** 2 + 5) ** 2),
             lambda z: 0.5 + z * float(2 * z ** 4 + 30 * z ** 2 + 135) / float(4 * (z ** 2 + 6) ** 2.5 ),
             _t_default,
             lambda z: 0.5 + z * float(z ** 6 + 28 * z ** 4 + 280 * z ** 2 + 1120) / float(2 * (z ** 2 + 8) ** 3.5),
             _t_default]

    if use_default :
        return _t_default
    return funcs[nu]
