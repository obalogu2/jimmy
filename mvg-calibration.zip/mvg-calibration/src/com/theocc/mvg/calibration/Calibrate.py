
import pandas
import sys
import os
import time

from com.theocc.mvg.calibration.data.TimeSeries import load_data
from com.theocc.mvg.calibration.functions.util import anderson_darling
from com.theocc.mvg.calibration.functions.util import standardized
from com.theocc.mvg.calibration.functions.util import scale_to_nu
from com.theocc.mvg.calibration.functions.univariate.volatilityEstimator import garch_fit
from com.theocc.mvg.calibration.functions.models import volatility_forecast
from com.theocc.mvg.calibration.config import configParser


if __name__ == "__main__":

    if len(sys.argv) < 2 :
        raise Exception("Missing config xml file")

    config = configParser.parse(sys.argv[1])

    verbose_dir = config['verbose_dir']
    verbose_status = config['verbose_status']
    dof_min = config['dof_min']
    dof_max = config['dof_max']
    occ_distribution = config['occ_distribution']
    risk_factors_type_code = config['risk_factors_type_code']
    volatility_estimator = config['volatility_estimator']
    alpha_min = float(config['alpha_min'])
    alpha_max = float(config['alpha_max'])
    beta_min = float(config['beta_min'])
    beta_max = float(config['beta_max'])
    horizon = float(config['horizon'])
    time_series_type = config['time_series_type']

    # Change the size of the picture dimension
    # fig_size = plt.rcParams["figure.figsize"]
    # fig_size[0] = 32
    # fig_size[1] = 24
    # plt.rcParams["figure.figsize"] = fig_size

    if verbose_status:
        try:
            if not os.path.exists(verbose_dir):
                os.makedirs(verbose_dir)
        except:
            raise IOError('Could not create folder %s' % verbose_dir)

    """
    Create a list of nu given a min(nu) and max(nu)
    """
    nu_list_size = 1
    nu_list = range(dof_min, dof_max+1)
    timeSeriesDataFrame = load_data(config)

    mean = timeSeriesDataFrame.mean(axis=0)
    variance = timeSeriesDataFrame.var(axis=0)
    sd = variance.apply(lambda x:x**0.5)

    if verbose_status:
        mean.to_csv("%s\\mean-pre-std.csv" % verbose_dir)
        sd.to_csv("%s\\sd-pre-std.csv" % verbose_dir)

    standardized_time_series = standardized(timeSeriesDataFrame, mean.copy(True), sd.copy(True))

    if verbose_status:
        standardized_time_series.to_csv("%s\\data_frame_standardized.csv" % verbose_dir)

    ad_stat = pandas.DataFrame(columns=nu_list)
    ad_prev = None
    dof = None

    timer = time.time()
    for nu in nu_list:
        data_frame_nu = scale_to_nu(standardized_time_series, nu)

        if verbose_status:
            data_frame_nu.to_csv("%s\\%d_data_frame_scale_nu.csv" % (verbose_dir, nu))
        ad = data_frame_nu.apply(anderson_darling, axis=0, args=(occ_distribution, [int(nu)]))

        if verbose_status:
            ad_stat[nu]=ad

        if ad_prev is None:
            ad_prev = ad
            dof = pandas.Series(index=ad.index, data=nu)

        else:
            for index in ad.index:
                if ad_prev[index] > ad[index]:
                    dof[index] = nu
            ad_prev = ad

    if verbose_status:

        ad_stat = ad_stat.transpose()
        ad_stat.to_csv("%s\\anderson_darling_result.csv" % verbose_dir)
        dof.to_csv("%s\\dof.csv" % verbose_dir)

    rf_names = timeSeriesDataFrame.columns

    if volatility_estimator == 'garch':
        parameter_data_frame = garch_fit(standardized_time_series, dof, alpha_min, alpha_max, beta_min, beta_max, horizon, verbose_dir)

        for rf in rf_names:
            alpha = parameter_data_frame.loc[rf, 'alpha']
            beta = parameter_data_frame.loc[rf, 'beta']
            parameter_data_frame.loc[rf][-1] = volatility_forecast(timeSeriesDataFrame.loc[:,rf], alpha, beta, mean.loc[rf], variance.loc[rf])

        # if verbose_status:
        parameter_data_frame.to_csv("%s\\parameter_data_frame.csv" % verbose_dir)

    print("timer(Fit) = %d" % (time.time() - timer))