
import xml.etree.ElementTree as xml_parser
from datetime import date


def parse(xml_config):
    config = xml_parser.parse(xml_config)
    mvg = config.getroot()

    config_param = dict()
    config_param['original_activity_date'] = None
    config_param['time_series_size'] = 0
    config_param['verbose_dir'] = None
    config_param['verbose_status'] = False
    config_param['symbols'] = []
    config_param['dof_min'] = -1
    config_param['dof_max'] = -1
    config_param['adjustment_type'] = -1
    config_param['max_missing_most_recent'] = -1
    config_param['occ_distribution'] = None
    config_param['risk_factors_type_code'] = None
    config_param['volatility_estimator'] = None
    config_param['alpha_min'] = 0.0
    config_param['alpha_max'] = 0.0
    config_param['beta_min'] = 0.0
    config_param['beta_max'] = 0.0
    config_param['horizon'] = -1
    config_param['time_series_type'] = "CC"

    for child in mvg:

        if child.tag == 'mvg-calibration':
            if child.find('originalActivityDate') is None :
                config_param['original_activity_date'] = date.strftime(date.today(), "%Y-%m-%d")
            else:
                config_param['original_activity_date'] = child.attrib['originalActivityDate']

            config_param['time_series_size'] = int(child.attrib['time-series-size'])
            config_param['time_series_type'] = child.attrib['time-series-type']
            config_param['occ_distribution'] = child.attrib['distribution']

            for grand_child in child:
                if grand_child.tag == 'verbose':
                    config_param['verbose_dir'] = grand_child.attrib['dir'] + '\\' + config_param['original_activity_date']
                    config_param['verbose_status'] = bool(grand_child.attrib['status'])

                elif grand_child.tag == 'risk-factors':

                    if len(grand_child.findall('risk-factors-type-code')) == 1:
                        config_param['risk_factors_type_code'] = grand_child.find('risk-factors-type-code').text

                    elif len(grand_child.findall('fin-Instr-Symbols')) == 1:
                        temp = grand_child.find('fin-Instr-Symbols')

                        for great_grand_child in temp:
                            config_param['symbols'].append(great_grand_child.text)
                    else:
                        raise Exception('risk-factors-type-code | fin-Instr-Symbols, both tags are not accepted')

                elif grand_child.tag == 'degree-of-freedom':
                    config_param['dof_min'] = int(grand_child.attrib['min'])
                    config_param['dof_max'] = int(grand_child.attrib['max'])

                elif grand_child.tag == 'adjustment-type':
                    config_param['adjustment_type'] = int(grand_child.attrib['value'])

                elif grand_child.tag == 'max-missing-most-recent':
                    config_param['max_missing_most_recent'] = int(grand_child.attrib['value'])

                elif grand_child.tag == 'volatility-estimator':
                    config_param['volatility_estimator'] = grand_child.attrib['type']
                    config_param['alpha_min'] = float(grand_child.attrib['alpha-min'])
                    config_param['alpha_max'] = float(grand_child.attrib['alpha-max'])
                    config_param['beta_min'] = float(grand_child.attrib['beta-min'])
                    config_param['beta_max'] = float(grand_child.attrib['beta-max'])
                    config_param['horizon'] = int(grand_child.attrib['horizon'])

                elif grand_child.tag == 'hdfs-host':
                    config_param['hdfs-host'] = grand_child.attrib['value']

                elif grand_child.tag == 'hdfs-port':
                    config_param['hdfs-port'] = int(grand_child.attrib['value'])

                elif grand_child.tag == 'local-temp-folder':
                    config_param['local-temp-folder'] = grand_child.attrib['value']

                elif grand_child.tag == 'hdfs-folder':
                    config_param['hdfs-folder'] = grand_child.attrib['value']


    return config_param
