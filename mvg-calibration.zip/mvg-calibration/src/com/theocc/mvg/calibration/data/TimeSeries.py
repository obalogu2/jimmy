
import pandas as pd


def load_data(config):

    """

    :param config:  a data dictionary of xml config contents
    :param activity_date: the activity date
    :return:        a data frame
    """

    data_frame = pd.DataFrame.from_csv( "%s\\%s" % (config['local-temp-folder'], 'LogReturns_2017-04-27.csv'))

    return data_frame
