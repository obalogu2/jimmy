
import pandas as pd
import math
import scipy as sc

from com.theocc.mvg.calibration.functions.util import demean
import unittest


class MultivariateModelTest(unittest.TestCase):

    __input_cov_matrix__ = None
    __input_raw_data_frame__ = None

    def setUp(self):
        self.__input_cov_matrix__ = pd.DataFrame.from_csv('C:\\OCC-Workspace\\ImpliedVol\\covM.csv', header=None, index_col=None)
        self.__input_raw_data_frame__ = pd.DataFrame.from_csv('C:\\OCC-Workspace\\ImpliedVol\\sampleM.csv', header=None, index_col=None)
        self.__input_raw_data_frame__ = self.__input_raw_data_frame__.dropna(axis=1)

    @staticmethod
    def __helper_multi_variate_model_cov__(input_data_frame, already_demean_ed=False, _need_transpose=False):

        input_data = input_data_frame.dropna(axis=1)

        if not already_demean_ed:
            input_data = input_data.apply(demean)

        if _need_transpose:
            input_data = input_data.T

        return input_data.cov()

    def test_cov(self):
        """

        This validation test verify the com.theocc.qrm.model.MultivariateModelTest

        The only way the test could pass was to modify the QRM test, because the covariance function implementation made assumption
        that the argument matrix is demeaned, but the actual data used in the test failed the demean test.

        This means that the covariance implementation is not concise, because it failed the traditional definition covariance function

        :return:
        """

        self_cov_matrix = self.__helper_multi_variate_model_cov__(self.__input_raw_data_frame__, False)
        self.assertIsNotNone(self_cov_matrix, 'The method does not create the covariance matrix')

        diff_matrix = self_cov_matrix.sub(self.__input_cov_matrix__)
        diff_matrix.applymap(lambda x: self.assertTrue(math.fabs(x) < 0.00001, 'receive %f, expecting %f' % (math.fabs(x), 0.00001)))

if __name__ == "__main__":
    # unittest.main()

    def f(X):
        x, y = X
        return (x-1)**2 + (y-1)**2

    x_opt = sc.optimize.minimize(f, (6, 123), method='BFGS')
    print x_opt